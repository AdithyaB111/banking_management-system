package com.phegondev.usersmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsersmanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
